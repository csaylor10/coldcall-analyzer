"use client";
import { useState } from "react";
import axios from "axios";
import { useDropzone } from "react-dropzone";

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [downloads, setDownloads] = useState([]);

const onDrop = async (acceptedFiles) => {
  if (acceptedFiles.length > 500) {
    setError("❌ You can upload up to 500 files at a time.");
    return;
  }

  setError("");
  setDownloads([]);
  setLoading(true);

  for (let file of acceptedFiles) {
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await axios.post(
        "http://129.153.137.7:8000/upload/",
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );

      const { analysis, overall_perf, rep_name, categorization } = res.data;

      // THIS IS THE CRUCIAL FIX CLEARLY:
      const filename = `${overall_perf} ${rep_name} ${categorization} ${file.name}.txt`;

      const blob = new Blob([analysis], { type: "text/plain" });
      const url = URL.createObjectURL(blob);

      setDownloads((prev) => [...prev, { name: filename, url }]);
    } catch (err) {
      console.error(err);
      setError(`❌ Error processing file ${file.name}`);
    }
  }
  setLoading(false);
};

  const { getRootProps, getInputProps } = useDropzone({ onDrop, multiple: true });

  return (
    <div className="p-10">
      {/* Clearly file upload section */}
      <div {...getRootProps()} className="border-2 border-dashed p-6 rounded cursor-pointer text-center">
        <input {...getInputProps()} multiple />
        <p>Drag & drop audio files (up to 500), or click to select files.</p>
      </div>

      {loading && <p className="mt-4">⏳ Processing files...</p>}

      {error && <p className="mt-4 text-red-500">{error}</p>}

      {/* Clearly downloadable files */}
      {downloads.length > 0 && (
        <div className="mt-4 p-4 bg-gray-100 rounded shadow">
          <h2 className="font-semibold">📁 Download Analysis Reports:</h2>
          <ul>
            {downloads.map((file, idx) => (
              <li key={idx}>
                <a href={file.url} download={file.name} className="text-blue-600 underline">
                  {file.name}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
